/*
 * Game.h
 *
 *  Created on: 1 oct. 2009
 *      Author: clement
 */

#ifndef GAME_H_
#define GAME_H_

#include "BaseObject.h"
#include "Engine.h"
#include "IMouse.h"
#include "IKeyboard.h"


#endif /* GAME_H_ */
