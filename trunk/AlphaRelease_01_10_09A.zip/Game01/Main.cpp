/*
 * Main.cpp
 *
 *  Created on: 1 oct. 2009
 *      Author: clement
 */

#include <stdio.h>
#include "Game.h"


int main(int argc, char ** argv)
{
	Engine e = Engine::GetInstance();
	e.InitAll(&argc,argv);
	e.Run();
	return 0;
}
