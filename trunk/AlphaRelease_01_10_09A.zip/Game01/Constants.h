/*
 * Constants.h
 *
 *  Created on: 1 oct. 2009
 *      Author: clement
 */

#ifndef CONSTANTS_H_
#define CONSTANTS_H_

#define MAX_NAME_LENGTH			128		//String length for name in BaseObject
#define ENGINE_STEP				10 		//Engine step in ms.

#endif /* CONSTANTS_H_ */
