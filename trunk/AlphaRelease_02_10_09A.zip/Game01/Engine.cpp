/*
 * Engine.cpp
 *
 *  Created on: 1 oct. 2009
 *      Author: clement
 */

#include "Engine.h"

void _display_func()
{
	Engine::GetInstance().GLDisplay();
}

void _timer_func(int id)
{
	Engine::GetInstance().GLTimer();
}

//Pour créer le Singleton, on init a NULL, pour le creer lors
//de la 1ere demande
Engine * Engine::_object = NULL;

Engine::Engine() : BaseObject()
{
	_init_passed = false;
	_resx = 0;
	_resy = 0;
	_ms_time = 0.0;
	_iviewable = NULL;
}

void Engine::InitAll(int *argc, char **argv, int resx, int resy, bool double_buffered, bool fullscreen)
{
	_resx = resx;
	_resy = resy;

	/*
	 * INITIALISATION D'OPENGL
	 */
	glutInit(argc, argv);
	if (double_buffered)
		glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	else
		glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
	glutInitWindowSize(resx,resy);
	glutCreateWindow("Futurattack - RIGOCOB Studios - 2009");

	glClearColor(0.0,0.0,0.0,1.0);

	_init_passed = true;
}

void Engine::Run()
{
	if (!_init_passed)
	{
		printf("Pass [Engine::InitAll] not done --> Exiting\n");
		return;
	}

	glutDisplayFunc(_display_func);
	glutTimerFunc(ENGINE_STEP,_timer_func,0);
	glutMainLoop();
}

void Engine::GLDisplay()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	if (_iviewable!=NULL)
	{
		_iviewable->PreRender();
		if (_iviewable->GetCamera().HasChanged())
			_iviewable->GetCamera().ApplyChanges();
		_iviewable->Render();
	}

	//---------------

	glutSwapBuffers();
}

void Engine::GLTimer()
{
	_ms_time += (float)ENGINE_STEP;
	glutPostRedisplay();
	glutTimerFunc(ENGINE_STEP,_timer_func,0);
}

void Engine::SetCurrentIViewable(IViewable & iviewable)
{
	_iviewable = &iviewable;
}

float Engine::GetCurrentTime()
{
	return _ms_time;
}

int Engine::GetScreenHeight()
{
	return _resy;
}

int Engine::GetScreenWidth()
{
	return _resx;
}

Engine::~Engine()
{
	// TODO Auto-generated destructor stub
}

Engine & Engine::GetInstance()
{
	if (_object==NULL)
		_object = new Engine();

	return *_object;
}

const char *Engine::ToString()
{
	return "Engine";
}




