/*
 * TestFrame.h
 *
 *  Created on: 1 oct. 2009
 *      Author: clement
 */

#ifndef TESTFRAME_H_
#define TESTFRAME_H_

#include <math.h>
#include "IViewable.h"
#include "Engine.h"

class TestFrame: public IViewable {
public:
	TestFrame();
	virtual ~TestFrame();

	void PreRender();
	void Render();
	const char * ToString();
};

#endif /* TESTFRAME_H_ */
