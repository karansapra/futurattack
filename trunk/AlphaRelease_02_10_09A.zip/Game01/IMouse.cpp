/*
 * IMouse.cpp
 *
 *  Created on: 1 oct. 2009
 *      Author: clement
 */

#include "IMouse.h"

IMouse::IMouse() : BaseObject() {
	// TODO Auto-generated constructor stub

}

IMouse::~IMouse() {
	// TODO Auto-generated destructor stub
}

const char *IMouse::ToString()
{
	return "IMouse";
}


