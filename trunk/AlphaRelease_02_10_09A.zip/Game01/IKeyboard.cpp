/*
 * IKeyboard.cpp
 *
 *  Created on: 1 oct. 2009
 *      Author: clement
 */

#include "IKeyboard.h"

IKeyboard::IKeyboard()  : BaseObject() {
	// TODO Auto-generated constructor stub
}

IKeyboard::~IKeyboard() {
	// TODO Auto-generated destructor stub
}

const char *IKeyboard::ToString()
{
	return "IKeyboard";
}


