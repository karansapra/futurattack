/*
 * Engine.h
 *
 *  Created on: 1 oct. 2009
 *      Author: clement
 */

#ifndef ENGINE_H_
#define ENGINE_H_

#include <stdio.h>
#include <GL/freeglut.h>
#include "BaseObject.h"
#include "IViewable.h"

//Pour permettre le rendu des frames
void _display_func();
void _timer_func(int id);

class Engine: public BaseObject {
	Engine();

	//Instance de l'objet en cours
	static Engine * _object;

	bool _init_passed;
	int _resx;
	int _resy;
	float _ms_time;

	IViewable * _iviewable;

public:
	static Engine & GetInstance();

	void InitAll(int * argc, char ** argv,int resx=640, int resy=480, bool double_buffered=true, bool fullscreen=false);
	void Run();
	float GetCurrentTime();

	void SetCurrentIViewable(IViewable & iviewable);
	int GetScreenWidth();
	int GetScreenHeight();

	void GLDisplay();
	void GLTimer();

	const char * ToString();
	virtual ~Engine();
};

#endif /* ENGINE_H_ */
