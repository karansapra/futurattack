/*
 * TestFrame.cpp
 *
 *  Created on: 1 oct. 2009
 *      Author: clement
 */

#include "TestFrame.h"

TestFrame::TestFrame() : IViewable() {
	float width = Engine::GetInstance().GetScreenWidth();
	float height = Engine::GetInstance().GetScreenHeight();
	_camera->SetEyePosition(0.0,0.0,10.0);
	_camera->SetVolumeView(-width/100.0,width/100.0,height/100.0,-height/100.0,0.00001,10000.0);
	_camera->SetLookAtPosition(0.0,0.0,0.0);
}

TestFrame::~TestFrame() {

}

void TestFrame::PreRender()
{
	_camera->Move(1.2*sin(6.28*Engine::GetInstance().GetCurrentTime()/10000.0),0.0,0.0);
	_camera->Zoom(2.0+sin(6.28*Engine::GetInstance().GetCurrentTime()/600.0));
}

void TestFrame::Render()
{
	glPushMatrix();
	glRotatef(Engine::GetInstance().GetCurrentTime()*360.0/3000.0,0.0,0.0,1.0);
	glBegin(GL_TRIANGLES);
		glColor3f(1.0f,0.0f,1.0f);
		glVertex3f(0.0,0.0,0.0);
		glColor3f(1.0f,1.0f,0.0f);
		glVertex3f(1.0,0.0,0.0);
		glColor3f(0.0f,1.0f,1.0f);
		glVertex3f(0.0,1.0,0.0);

		glColor3f(1.0f,0.0f,1.0f);
		glVertex3f(0.0,0.0,0.0);
		glColor3f(1.0f,1.0f,0.0f);
		glVertex3f(-1.0,0.0,0.0);
		glColor3f(0.0f,1.0f,1.0f);
		glVertex3f(0.0,-1.0,0.0);
	glEnd();
	glPopMatrix();
}

const char *TestFrame::ToString()
{
	return "TestFrame";
}


