/*
 * IRenderable.cpp
 *
 *  Created on: 1 oct. 2009
 *      Author: clement
 */

#include "IRenderable.h"

IRenderable::IRenderable() {
	// TODO Auto-generated constructor stub

}

IRenderable::~IRenderable() {
	// TODO Auto-generated destructor stub
}

void IRenderable::PreRender()
{
}

const char *IRenderable::ToString()
{
	return "IRenderable";
}


