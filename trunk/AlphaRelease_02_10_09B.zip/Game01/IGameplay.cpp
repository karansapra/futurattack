/*
 * IGameplay.cpp
 *
 *  Created on: 2 oct. 2009
 *      Author: clement
 */

#include "IGameplay.h"

IGameplay::IGameplay() {
	// TODO Auto-generated constructor stub

}

IGameplay::~IGameplay() {
	// TODO Auto-generated destructor stub
}
